import os
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA
from .ingest import get_vectorstore
from config import OPENAI_API_KEY


def get_rag_chain():
    """Create a RetrievalQA chain using the vectorstore."""
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set. Please set it in environment / Streamlit secrets.")

    os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

    vectorstore = get_vectorstore()
    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": 4}
    )

    llm = ChatOpenAI(
        model="gpt-4o-mini",  # you can change this model
        temperature=0
    )

    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type="stuff",
        return_source_documents=True,
    )

    return qa_chain
